package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NextPageActivity extends AppCompatActivity {

    private Button btnBorrowBook, btnReturnBook, btnSearchBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_page);

        btnBorrowBook = findViewById(R.id.btnBorrowBook);
        btnReturnBook = findViewById(R.id.btnReturnBook);
        btnSearchBook = findViewById(R.id.btnSearchBook);

        btnBorrowBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start BorrowBookActivity
                startActivity(new Intent(NextPageActivity.this, BorrowBookActivity.class));
            }
        });

        btnReturnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start ReturnBookActivity
                startActivity(new Intent(NextPageActivity.this, ReturnBookActivity.class));
            }
        });

        btnSearchBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement your searchBooks functionality here
                startActivity(new Intent(NextPageActivity.this, SearchBooksActivity.class));
                //Toast.makeText(NextPageActivity.this, "Search for Books functionality", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
