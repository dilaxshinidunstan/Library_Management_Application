package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SearchResultsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        // Retrieve the search query from the intent
        String searchQuery = getIntent().getStringExtra("SEARCH_QUERY");

        // Display the search query in a TextView
        TextView textViewSearchQuery = findViewById(R.id.textViewSearchQuery);
        textViewSearchQuery.setText("Search Query: " + searchQuery);

        // Perform search operation and display results if needed
        // You can modify this part to display search results as per your requirement
    }
}
