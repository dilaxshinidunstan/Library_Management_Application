package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import com.example.myapplication.database.BookContract;
import com.example.myapplication.database.BookDbHelper;
import android.content.ContentValues;

public class ReturnBookActivity extends AppCompatActivity {
    private BookDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.return_book_activity);

        // Initialize database helper
        dbHelper = new BookDbHelper(this);

        // Handle the return button click
        Button returnButton = findViewById(R.id.buttonReturn);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnBook();
            }
        });

        // Handle the back button click
        Button backButton = findViewById(R.id.buttonBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the previous activity
                finish();
            }
        });
    }

    private void returnBook() {
        // Get the book details from the EditText fields
        EditText editTextBookTitle = findViewById(R.id.editTextBookTitle);
        String title = editTextBookTitle.getText().toString();

        EditText editTextAuthor = findViewById(R.id.editTextAuthor);
        String author = editTextAuthor.getText().toString();

        EditText editTextISBN = findViewById(R.id.editTextISBN);
        String isbn = editTextISBN.getText().toString();

        EditText editTextBorrower = findViewById(R.id.editTextBorrower);
        String borrower = editTextBorrower.getText().toString();

        EditText editTextBorrowDate = findViewById(R.id.editTextBorrowDate);
        String borrowDate = editTextBorrowDate.getText().toString();

        // Open the writable database
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Create a ContentValues object to store the updated values
        ContentValues values = new ContentValues();
        values.put(BookContract.BookEntry.COLUMN_TITLE, title);
        values.put(BookContract.BookEntry.COLUMN_AUTHOR, author);
        values.put(BookContract.BookEntry.COLUMN_ISBN, isbn);
        values.put(BookContract.BookEntry.COLUMN_BORROWER, borrower);
        values.put(BookContract.BookEntry.COLUMN_BORROW_DATE, borrowDate);

        // Insert data into the database
        long newRowId = db.insert(BookContract.BookEntry.TABLE_NAME, null, values);

        // Check if the insertion was successful
        if (newRowId != -1) {
            // If the insertion is successful, display a success message
            Toast.makeText(this, "Book returned successfully", Toast.LENGTH_SHORT).show();
        } else {
            // If the insertion fails, display an error message
            Toast.makeText(this, "Failed to return the book", Toast.LENGTH_SHORT).show();
        }

        // Close the database
        db.close();
    }
}
