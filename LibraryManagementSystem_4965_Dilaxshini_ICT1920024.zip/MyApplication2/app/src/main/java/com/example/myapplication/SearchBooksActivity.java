// SearchBooksActivity.java

package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.myapplication.database.BookContract;
import com.example.myapplication.database.BookDbHelper;

public class SearchBooksActivity extends AppCompatActivity {

    private EditText editTextSearchTitle;
    private BookDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_books);

        // Initialize EditText
        editTextSearchTitle = findViewById(R.id.editTextSearchTitle);

        // Initialize database helper
        dbHelper = new BookDbHelper(this);

        // Setup search button click listener
        Button buttonSearch = findViewById(R.id.buttonSearch);
        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performSearch();
            }
        });

        // Setup back button click listener
        Button buttonBack = findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the current activity to go back
                finish();
            }
        });
    }

    private void performSearch() {
        // Get search query
        String searchQuery = editTextSearchTitle.getText().toString();

        // Perform search operation (Check if the book exists in the books table)
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                BookContract.BookEntry.COLUMN_TITLE
        };
        String selection = BookContract.BookEntry.COLUMN_TITLE + " LIKE ?";
        String[] selectionArgs = { "%" + searchQuery + "%" };

        Cursor cursor = db.query(
                BookContract.BookEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        // Check if any matching books found
        if (cursor.getCount() > 0) {
            // Display matching books
            StringBuilder booksList = new StringBuilder();
            while (cursor.moveToNext()) {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(BookContract.BookEntry.COLUMN_TITLE));
                booksList.append(title).append("\n");
            }
            Toast.makeText(this, "Matching Books:\n" + booksList.toString(), Toast.LENGTH_LONG).show();
        } else {
            // No matching books found
            Toast.makeText(this, "No books found with the title '" + searchQuery + "'", Toast.LENGTH_SHORT).show();
        }

        // Close the cursor and database
        cursor.close();
        db.close();
    }
}
