package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Intent;
import com.example.myapplication.database.BookContract;
import com.example.myapplication.database.BookDbHelper;

public class BorrowBookActivity extends AppCompatActivity {
    private BookDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.borrow_book_activity);

        // Initialize database helper
        dbHelper = new BookDbHelper(this);

        // Insert data into database when borrow button is clicked
        Button borrowButton = findViewById(R.id.buttonBorrow);
        borrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertBook();
            }
        });

        // Add return button functionality
        Button returnButton = findViewById(R.id.buttonBack);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the previous activity
                finish();
            }
        });
    }

    private void insertBook() {
        // Get user input from EditText fields
        EditText editTextTitle = findViewById(R.id.editTextTitle);
        EditText editTextAuthor = findViewById(R.id.editTextAuthor);
        EditText editTextISBN = findViewById(R.id.editTextISBN);
        EditText editTextBorrower = findViewById(R.id.editTextBorrower);
        EditText editTextBorrowDate = findViewById(R.id.editTextBorrowDate);

        String title = editTextTitle.getText().toString();
        String author = editTextAuthor.getText().toString();
        String isbn = editTextISBN.getText().toString();
        String borrower = editTextBorrower.getText().toString();
        String borrowDate = editTextBorrowDate.getText().toString();

        // Open the writable database
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Create a ContentValues object and put the input data into it
        ContentValues values = new ContentValues();
        values.put(BookContract.BookEntry.COLUMN_TITLE, title);
        values.put(BookContract.BookEntry.COLUMN_AUTHOR, author);
        values.put(BookContract.BookEntry.COLUMN_ISBN, isbn);
        values.put(BookContract.BookEntry.COLUMN_BORROWER, borrower);
        values.put(BookContract.BookEntry.COLUMN_BORROW_DATE, borrowDate);

        // Insert data into the database
        long newRowId = db.insert(BookContract.BookEntry.TABLE_NAME, null, values);

        // Check if the insertion was successful
        if (newRowId != -1) {
            // If the insertion is successful, navigate to BorrowSuccessActivity
            Intent intent = new Intent(this, BorrowSuccessActivity.class);
            startActivity(intent);
        } else {
            // If the insertion fails, display an error message
            Toast.makeText(this, "Error saving book details", Toast.LENGTH_SHORT).show();
        }
    }
}
