package com.example.myapplication.database;

import android.provider.BaseColumns;

public final class BookContract {
    private BookContract() {} // Private constructor to prevent instantiation

    public static class BookEntry implements BaseColumns {
        public static final String TABLE_NAME = "books";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_AUTHOR = "author";
        public static final String COLUMN_ISBN = "isbn";
        public static final String COLUMN_BORROWER = "borrower";
        public static final String COLUMN_BORROW_DATE = "borrow_date";
        public static final String COLUMN_PUBLISHER = "publisher"; // Added
        public static final String COLUMN_GENRE = "genre"; // Added
    }
}
